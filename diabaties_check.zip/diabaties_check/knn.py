

import matplotlib.pyplot as plt;
import numpy as np;
import pandas as pd;
from sklearn import preprocessing
fil=pd.read_csv("check1.csv");
print(fil);
print(type(fil));
fil=fil.drop(['DiabetesPedigreeFunction'],axis=1);
print(fil);
out=fil['Outcome'];
print(out[0]," ",out[760]);
fil=fil.drop(['Outcome'],axis=1);
row,col=fil.shape;
print(row,col);
u=[];
for col in fil.columns:
  u.append(col);
print(u);

train=fil.head(700);
test=fil.tail(len(fil)-700);
print(train);
print(test);
n=len(fil);
n1=len(train);
acc=0;
print(out);
for i in range(n1,n,1):
    ub=test.loc[i,:];
    dis=[];
    for j in range(0,n1,1):
        ua=train.loc[j,:];
        val=np.linalg.norm(ub-ua)
        dis.append(val);
    ind=[];
    for il in range(0,n1,1):
      ind.append(il);
    for la in range(0,n1,1):
        for lb in range(la+1,n1,1):
              if(dis[lb]<dis[la]):
                     temp=ind[lb];
                     ind[lb]=ind[la];
                     ind[la]=temp;
    n11=0;
    n00=0;
    for vau in range(20):
           if(out[ind[vau]]==0):
                n00=n00+1;
           else:
                n11=n11+1;
    if(n00>n11):
        nf=0;
    else:
        nf=1;
    if(out[i]==nf):
        acc=acc+1;
vag=n-n1;
vac=float(acc/vag)*100;
print(acc);
print("Accuracy is ",vac,'%');

